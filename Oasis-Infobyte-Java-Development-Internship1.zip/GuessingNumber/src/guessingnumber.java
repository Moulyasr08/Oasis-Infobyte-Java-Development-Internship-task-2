import java.util.Random;
import java.util.Scanner;

public class guessingnumber {
	    public static void main(String[] args) {
	        int score = 0;
	        int lives = 3;
	        
	        System.out.println("Welcome to the Number Guessing Game!");
	        System.out.println("You have " + lives + " lives. Try to guess the number!");

	        Random random = new Random();
	        int targetNumber = random.nextInt(100) + 1;

	        Scanner scanner = new Scanner(System.in);
	        boolean isGameOver = false;

	        while (!isGameOver) {
	            System.out.print("Enter your guess: ");
	            int guess = scanner.nextInt();
                
	            if (guess == targetNumber) {
	                System.out.println("Congratulations! You guessed the correct number.");
	                score += 10;
	                System.out.println("Score: " + score);

	                System.out.println("Do you want to play again? (yes/no)");
	                String playAgain = scanner.next();

	                if (playAgain.equalsIgnoreCase("no")) {
	                    isGameOver = true;
	                    System.out.println("Thanks for playing. Goodbye!");
	                } else {
	                    targetNumber = random.nextInt(100) + 1;
	                    System.out.println("New number generated. Guess again!");
	                }
	            } else {
	                lives--;
	                System.out.println("Wrong guess! Lives remaining: " + lives);

	                if (lives == 0) {
	                    isGameOver = true;
	                    System.out.println("Game over! You ran out of lives.");
	                    System.out.println("Final Score: " + score);
	                } else if (guess < targetNumber) {
	                    System.out.println("Try guessing higher...");
	                } else {
	                    System.out.println("Try guessing lower...");
	                }
	            }
	        }

	        scanner.close();
	    }
	}


